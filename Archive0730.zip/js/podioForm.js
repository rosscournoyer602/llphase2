$(document).ready(() => {
  $('.webform').addClass('webform-responsive');
});