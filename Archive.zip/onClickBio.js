/* eslint-disable prefer-arrow-callback */
/* eslint-disable no-undef */
// eslint-disable-next-line no-unused-vars
function addClick(bio) {
  bio.classList.toggle('visible');
}
// document.body.on('load', () => {
//   document.body.getElementsByClassName('partner-bio-content').forEach(element => {
//     console.log(element);
//   });
// });
