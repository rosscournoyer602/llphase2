/* eslint-disable func-names */
/* eslint-disable prefer-arrow-callback */
/* eslint-disable no-undef */
// eslint-disable-next-line no-unused-vars
function addClick(bio) {
  console.log('click');
  bio.classList.toggle('visible');
}
// document.body.on('load', () => {
//   document.body.getElementsByClassName('partner-bio-content').forEach(element => {
//     console.log(element);
//   });
// });
// $('.partner-bio-content').on('touchstart', function(e) {
//   console.log('touchstrt');
//   e.target.classList.toggle('visible');
// });
